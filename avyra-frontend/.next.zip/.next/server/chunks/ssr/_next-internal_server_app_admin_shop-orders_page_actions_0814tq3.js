module.exports=[97070,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_shop-orders_page_actions_0814tq3.js.map