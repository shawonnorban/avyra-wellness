1:"$Sreact.fragment"
2:I[64608,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/3w2ct1d0t9l38.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/00ytsfx1-ylw9.js","/_next/static/chunks/3to4_2r9xpqu2.js","/_next/static/chunks/1wb99hg6cap0t.js","/_next/static/chunks/0-ck5u1f3yge9.js","/_next/static/chunks/0c5hz_blulzdp.js","/_next/static/chunks/3gnwqullmbdyz.js"],"PolicyPage"]
3:I[97367,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/3w2ct1d0t9l38.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/00ytsfx1-ylw9.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"policy":"terms"}],[["$","script","script-0",{"src":"/_next/static/chunks/0c5hz_blulzdp.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/3gnwqullmbdyz.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"_WVqZSknq2EHWYcjV2hCz"}
5:null
