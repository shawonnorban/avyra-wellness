1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/3w2ct1d0t9l38.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/00ytsfx1-ylw9.js"],"default"]
3:I[37457,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/3w2ct1d0t9l38.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/00ytsfx1-ylw9.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"_WVqZSknq2EHWYcjV2hCz"}
