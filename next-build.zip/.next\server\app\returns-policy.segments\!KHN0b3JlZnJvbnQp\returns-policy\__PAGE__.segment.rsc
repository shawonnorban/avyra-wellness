1:"$Sreact.fragment"
2:I[64608,["/_next/static/chunks/111ttwmih38kb.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js","/_next/static/chunks/3lnd00f11mq9s.js","/_next/static/chunks/1wb99hg6cap0t.js","/_next/static/chunks/3jszi5w_24xat.js","/_next/static/chunks/0c5hz_blulzdp.js","/_next/static/chunks/3gnwqullmbdyz.js"],"PolicyPage"]
3:I[97367,["/_next/static/chunks/111ttwmih38kb.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"policy":"returns"}],[["$","script","script-0",{"src":"/_next/static/chunks/0c5hz_blulzdp.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/3gnwqullmbdyz.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jPL1C-SNoZsYSz8yOCht5"}
5:null
