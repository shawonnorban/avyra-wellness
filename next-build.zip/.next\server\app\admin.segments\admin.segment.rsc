1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/416_8i31yxxbw.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js"],"ClientSegmentRoot"]
3:I[88760,["/_next/static/chunks/416_8i31yxxbw.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js","/_next/static/chunks/3gnwqullmbdyz.js","/_next/static/chunks/3jszi5w_24xat.js","/_next/static/chunks/1k3z5sdltsr7u.js"],"default"]
4:I[39756,["/_next/static/chunks/416_8i31yxxbw.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js"],"default"]
5:I[37457,["/_next/static/chunks/416_8i31yxxbw.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3gnwqullmbdyz.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/3jszi5w_24xat.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/1k3z5sdltsr7u.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"LRvw0sPamiBZIswmYIfM2"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
