1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/0wxjqqp6uebov.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/38i01s-2kiop3.js"],"default"]
3:I[37457,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/0wxjqqp6uebov.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/38i01s-2kiop3.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"JbORC3Afh_CzJdTMSxMZM"}
