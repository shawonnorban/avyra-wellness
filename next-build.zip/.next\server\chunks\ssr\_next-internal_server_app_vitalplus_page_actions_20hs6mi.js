module.exports=[8047,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_vitalplus_page_actions_20hs6mi.js.map