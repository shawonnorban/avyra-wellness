module.exports=[9750,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_lp_%5Bslug%5D_page_actions_0coo61w.js.map