module.exports=[93769,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_purchase_page_actions_08axm15.js.map