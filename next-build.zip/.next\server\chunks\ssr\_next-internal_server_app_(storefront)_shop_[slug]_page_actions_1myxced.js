module.exports=[68932,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28storefront%29_shop_%5Bslug%5D_page_actions_1myxced.js.map