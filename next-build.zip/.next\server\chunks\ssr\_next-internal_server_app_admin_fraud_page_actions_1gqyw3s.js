module.exports=[68822,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_fraud_page_actions_1gqyw3s.js.map