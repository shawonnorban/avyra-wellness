:HL["/_next/static/chunks/0h2ziiclxjxd1.css","style"]
:HL["/_next/static/media/0dc02305a3505331-s.p.0dhp2_wm7tc69.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/a3cbd21e22af91be-s.p.0ue44297wro2j.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/c3d513372510d053-s.p.43q446cqtmrkj.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/c41ca59f1c34ba31-s.p.2y2uoi4t910qy.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"(storefront)","param":null,"prefetchHints":0,"slots":{"children":{"name":"returns-policy","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"Mi2ZHxqy45-iQoi1Nnu_P"}
