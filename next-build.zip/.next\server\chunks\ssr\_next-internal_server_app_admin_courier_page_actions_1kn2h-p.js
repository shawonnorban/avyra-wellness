module.exports=[59477,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_courier_page_actions_1kn2h-p.js.map