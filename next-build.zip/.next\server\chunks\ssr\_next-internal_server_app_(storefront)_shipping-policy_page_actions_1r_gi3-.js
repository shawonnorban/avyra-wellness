module.exports=[53289,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28storefront%29_shipping-policy_page_actions_1r_gi3-.js.map