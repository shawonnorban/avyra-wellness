1:"$Sreact.fragment"
2:I[64608,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/1fiezd22sbxnw.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/38i01s-2kiop3.js","/_next/static/chunks/1zy6_4p7hl2b1.js","/_next/static/chunks/1wb99hg6cap0t.js","/_next/static/chunks/1z77_sb_hrazx.js","/_next/static/chunks/0c5hz_blulzdp.js","/_next/static/chunks/3gnwqullmbdyz.js"],"PolicyPage"]
3:I[97367,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/1fiezd22sbxnw.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/38i01s-2kiop3.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"policy":"terms"}],[["$","script","script-0",{"src":"/_next/static/chunks/0c5hz_blulzdp.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/3gnwqullmbdyz.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"N8KAmJLWv35eBdWrqsjKs"}
5:null
