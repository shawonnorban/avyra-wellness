globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/PAzH5FUIZ33opLaXuoh7t/_buildManifest.js",
    "static/PAzH5FUIZ33opLaXuoh7t/_ssgManifest.js",
    "static/PAzH5FUIZ33opLaXuoh7t/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/36ssnkm0cjgq6.js",
    "static/chunks/0fz8c-gzr3hmy.js",
    "static/chunks/0hnx_nnkt0z_e.js",
    "static/chunks/0pgs2wzbm29i0.js",
    "static/chunks/3aacjsbz-hbsu.js",
    "static/chunks/turbopack-3w3a-agitshfb.js"
  ]
};
