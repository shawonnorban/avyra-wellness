globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/jPL1C-SNoZsYSz8yOCht5/_buildManifest.js",
    "static/jPL1C-SNoZsYSz8yOCht5/_ssgManifest.js",
    "static/jPL1C-SNoZsYSz8yOCht5/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2x88qpvew7nvy.js",
    "static/chunks/3aacjsbz-hbsu.js",
    "static/chunks/2uz925kbuthj6.js",
    "static/chunks/0hnx_nnkt0z_e.js",
    "static/chunks/turbopack-333ifuhoy3ok3.js"
  ]
};
