module.exports=[66705,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28storefront%29_vital-plus_page_actions_14dkdak.js.map