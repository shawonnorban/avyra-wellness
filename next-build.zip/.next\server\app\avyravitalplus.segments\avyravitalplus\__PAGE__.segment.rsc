1:"$Sreact.fragment"
2:I[14138,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/1mi028yxvr7_2.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/38i01s-2kiop3.js","/_next/static/chunks/1udeaf1gawv31.js","/_next/static/chunks/1wb99hg6cap0t.js"],"CampaignPage"]
3:I[97367,["/_next/static/chunks/44u72ydq75yuw.js","/_next/static/chunks/1mi028yxvr7_2.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/38i01s-2kiop3.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/2mrf1736p79on.css","style"]
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2mrf1736p79on.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/1udeaf1gawv31.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/1wb99hg6cap0t.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"PAzH5FUIZ33opLaXuoh7t"}
5:null
