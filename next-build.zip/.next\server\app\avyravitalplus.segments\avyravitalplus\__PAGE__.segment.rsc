1:"$Sreact.fragment"
2:I[14138,["/_next/static/chunks/111ttwmih38kb.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js","/_next/static/chunks/304mauakf5gdx.js","/_next/static/chunks/04r3r67he4a6q.js","/_next/static/chunks/3jszi5w_24xat.js","/_next/static/chunks/1wb99hg6cap0t.js"],"CampaignPage"]
3:I[97367,["/_next/static/chunks/111ttwmih38kb.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1rm4opgv51c4_.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/2mrf1736p79on.css","style"]
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2mrf1736p79on.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/304mauakf5gdx.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/04r3r67he4a6q.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/3jszi5w_24xat.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/1wb99hg6cap0t.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jPL1C-SNoZsYSz8yOCht5"}
5:null
