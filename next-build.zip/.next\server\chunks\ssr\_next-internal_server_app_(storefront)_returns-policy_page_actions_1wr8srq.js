module.exports=[81538,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28storefront%29_returns-policy_page_actions_1wr8srq.js.map