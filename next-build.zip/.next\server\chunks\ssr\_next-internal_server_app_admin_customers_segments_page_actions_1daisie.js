module.exports=[25765,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_customers_segments_page_actions_1daisie.js.map